<?php
echo '<h1>PHP works!</h1>';