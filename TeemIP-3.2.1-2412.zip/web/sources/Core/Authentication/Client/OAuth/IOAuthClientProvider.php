<?php
namespace Combodo\iTop\Core\Authentication\Client\OAuth;

interface IOAuthClientProvider{
}